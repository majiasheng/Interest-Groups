package data;

import java.io.Serializable;

/**
 *
 * @author majiasheng
 */

/**
 * 
 */
public class Post  implements Serializable{
    private String group;
    private String subject;
    private String author;
    private String date;
    private boolean isRead;

    public Post() {

    }

}